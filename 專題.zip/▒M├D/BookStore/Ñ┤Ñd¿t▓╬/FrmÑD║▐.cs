﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace BookStore.打卡系統
{
    public partial class Frm主管 : frm打卡
    {
        public Frm主管()
        {
            InitializeComponent();
        }
    }
}
