﻿namespace Form_Verify
{
    partial class Frm_Verify_Holiday_Annabel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_verify_holi_title = new System.Windows.Forms.Label();
            this.lbl_verify_holi_list = new System.Windows.Forms.Label();
            this.dgv_verify_holi_list = new System.Windows.Forms.DataGridView();
            this.lbl_verify_holi_proove = new System.Windows.Forms.Label();
            this.btn_verify_holi_open = new System.Windows.Forms.Button();
            this.picbox_verify_holi = new System.Windows.Forms.PictureBox();
            this.btn_verify_cancel = new System.Windows.Forms.Button();
            this.btn_verify_ok = new System.Windows.Forms.Button();
            this.lbl_verify_holi_rea = new System.Windows.Forms.Label();
            this.lbl_verify_holi_empid = new System.Windows.Forms.Label();
            this.lbl_verify_holi_id = new System.Windows.Forms.Label();
            this.lbl_verify_holi_id_show = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_verify_holi_name = new System.Windows.Forms.Label();
            this.lbl_verify_holi_jobchange = new System.Windows.Forms.Label();
            this.lbl_verify_holi_offday_category = new System.Windows.Forms.Label();
            this.lbl_verify_holi_startdate = new System.Windows.Forms.Label();
            this.lbl_verify_holi_endDate = new System.Windows.Forms.Label();
            this.lbl_verify_holi_offdayDays = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_verify_holi_status = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_verify_holi_list)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_verify_holi)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_verify_holi_title
            // 
            this.lbl_verify_holi_title.AutoSize = true;
            this.lbl_verify_holi_title.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_title.Location = new System.Drawing.Point(44, 42);
            this.lbl_verify_holi_title.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_verify_holi_title.Name = "lbl_verify_holi_title";
            this.lbl_verify_holi_title.Size = new System.Drawing.Size(86, 24);
            this.lbl_verify_holi_title.TabIndex = 1;
            this.lbl_verify_holi_title.Text = "假單審核";
            // 
            // lbl_verify_holi_list
            // 
            this.lbl_verify_holi_list.AutoSize = true;
            this.lbl_verify_holi_list.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_list.ForeColor = System.Drawing.Color.Firebrick;
            this.lbl_verify_holi_list.Location = new System.Drawing.Point(47, 113);
            this.lbl_verify_holi_list.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_list.Name = "lbl_verify_holi_list";
            this.lbl_verify_holi_list.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_list.TabIndex = 2;
            this.lbl_verify_holi_list.Text = "假單列表";
            // 
            // dgv_verify_holi_list
            // 
            this.dgv_verify_holi_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_verify_holi_list.Location = new System.Drawing.Point(49, 150);
            this.dgv_verify_holi_list.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv_verify_holi_list.Name = "dgv_verify_holi_list";
            this.dgv_verify_holi_list.RowTemplate.Height = 24;
            this.dgv_verify_holi_list.Size = new System.Drawing.Size(320, 212);
            this.dgv_verify_holi_list.TabIndex = 3;
            // 
            // lbl_verify_holi_proove
            // 
            this.lbl_verify_holi_proove.AutoSize = true;
            this.lbl_verify_holi_proove.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_proove.ForeColor = System.Drawing.Color.Firebrick;
            this.lbl_verify_holi_proove.Location = new System.Drawing.Point(47, 394);
            this.lbl_verify_holi_proove.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_proove.Name = "lbl_verify_holi_proove";
            this.lbl_verify_holi_proove.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_proove.TabIndex = 4;
            this.lbl_verify_holi_proove.Text = "證明文件";
            // 
            // btn_verify_holi_open
            // 
            this.btn_verify_holi_open.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_verify_holi_open.Location = new System.Drawing.Point(50, 685);
            this.btn_verify_holi_open.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_verify_holi_open.Name = "btn_verify_holi_open";
            this.btn_verify_holi_open.Size = new System.Drawing.Size(100, 33);
            this.btn_verify_holi_open.TabIndex = 5;
            this.btn_verify_holi_open.Text = "Open...";
            this.btn_verify_holi_open.UseVisualStyleBackColor = true;
            // 
            // picbox_verify_holi
            // 
            this.picbox_verify_holi.Location = new System.Drawing.Point(50, 431);
            this.picbox_verify_holi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picbox_verify_holi.Name = "picbox_verify_holi";
            this.picbox_verify_holi.Size = new System.Drawing.Size(320, 201);
            this.picbox_verify_holi.TabIndex = 6;
            this.picbox_verify_holi.TabStop = false;
            // 
            // btn_verify_cancel
            // 
            this.btn_verify_cancel.BackColor = System.Drawing.Color.Firebrick;
            this.btn_verify_cancel.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_verify_cancel.ForeColor = System.Drawing.Color.Transparent;
            this.btn_verify_cancel.Location = new System.Drawing.Point(803, 824);
            this.btn_verify_cancel.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btn_verify_cancel.Name = "btn_verify_cancel";
            this.btn_verify_cancel.Size = new System.Drawing.Size(145, 44);
            this.btn_verify_cancel.TabIndex = 28;
            this.btn_verify_cancel.Text = "退件";
            this.btn_verify_cancel.UseVisualStyleBackColor = false;
            // 
            // btn_verify_ok
            // 
            this.btn_verify_ok.BackColor = System.Drawing.Color.OliveDrab;
            this.btn_verify_ok.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_verify_ok.ForeColor = System.Drawing.Color.Transparent;
            this.btn_verify_ok.Location = new System.Drawing.Point(621, 824);
            this.btn_verify_ok.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.btn_verify_ok.Name = "btn_verify_ok";
            this.btn_verify_ok.Size = new System.Drawing.Size(145, 44);
            this.btn_verify_ok.TabIndex = 27;
            this.btn_verify_ok.Text = "通過";
            this.btn_verify_ok.UseVisualStyleBackColor = false;
            // 
            // lbl_verify_holi_rea
            // 
            this.lbl_verify_holi_rea.AutoSize = true;
            this.lbl_verify_holi_rea.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_rea.Location = new System.Drawing.Point(477, 526);
            this.lbl_verify_holi_rea.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_verify_holi_rea.Name = "lbl_verify_holi_rea";
            this.lbl_verify_holi_rea.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_rea.TabIndex = 31;
            this.lbl_verify_holi_rea.Text = "請假原因";
            // 
            // lbl_verify_holi_empid
            // 
            this.lbl_verify_holi_empid.AutoSize = true;
            this.lbl_verify_holi_empid.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_empid.Location = new System.Drawing.Point(475, 100);
            this.lbl_verify_holi_empid.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_verify_holi_empid.Name = "lbl_verify_holi_empid";
            this.lbl_verify_holi_empid.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_empid.TabIndex = 29;
            this.lbl_verify_holi_empid.Text = "員工編號";
            // 
            // lbl_verify_holi_id
            // 
            this.lbl_verify_holi_id.AutoSize = true;
            this.lbl_verify_holi_id.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_id.Location = new System.Drawing.Point(475, 49);
            this.lbl_verify_holi_id.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_verify_holi_id.Name = "lbl_verify_holi_id";
            this.lbl_verify_holi_id.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_id.TabIndex = 35;
            this.lbl_verify_holi_id.Text = "申請編號";
            // 
            // lbl_verify_holi_id_show
            // 
            this.lbl_verify_holi_id_show.AutoSize = true;
            this.lbl_verify_holi_id_show.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_id_show.Location = new System.Drawing.Point(619, 53);
            this.lbl_verify_holi_id_show.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_id_show.Name = "lbl_verify_holi_id_show";
            this.lbl_verify_holi_id_show.Size = new System.Drawing.Size(16, 17);
            this.lbl_verify_holi_id_show.TabIndex = 36;
            this.lbl_verify_holi_id_show.Text = "1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(619, 104);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 17);
            this.label5.TabIndex = 37;
            this.label5.Text = "12423435";
            // 
            // lbl_verify_holi_name
            // 
            this.lbl_verify_holi_name.AutoSize = true;
            this.lbl_verify_holi_name.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_name.Location = new System.Drawing.Point(476, 160);
            this.lbl_verify_holi_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_name.Name = "lbl_verify_holi_name";
            this.lbl_verify_holi_name.Size = new System.Drawing.Size(34, 17);
            this.lbl_verify_holi_name.TabIndex = 38;
            this.lbl_verify_holi_name.Text = "姓名";
            // 
            // lbl_verify_holi_jobchange
            // 
            this.lbl_verify_holi_jobchange.AutoSize = true;
            this.lbl_verify_holi_jobchange.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_jobchange.Location = new System.Drawing.Point(476, 213);
            this.lbl_verify_holi_jobchange.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_jobchange.Name = "lbl_verify_holi_jobchange";
            this.lbl_verify_holi_jobchange.Size = new System.Drawing.Size(73, 17);
            this.lbl_verify_holi_jobchange.TabIndex = 39;
            this.lbl_verify_holi_jobchange.Text = "職務代理人";
            // 
            // lbl_verify_holi_offday_category
            // 
            this.lbl_verify_holi_offday_category.AutoSize = true;
            this.lbl_verify_holi_offday_category.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_offday_category.Location = new System.Drawing.Point(476, 263);
            this.lbl_verify_holi_offday_category.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_offday_category.Name = "lbl_verify_holi_offday_category";
            this.lbl_verify_holi_offday_category.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_offday_category.TabIndex = 40;
            this.lbl_verify_holi_offday_category.Text = "請假類別";
            // 
            // lbl_verify_holi_startdate
            // 
            this.lbl_verify_holi_startdate.AutoSize = true;
            this.lbl_verify_holi_startdate.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_startdate.Location = new System.Drawing.Point(476, 313);
            this.lbl_verify_holi_startdate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_startdate.Name = "lbl_verify_holi_startdate";
            this.lbl_verify_holi_startdate.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_startdate.TabIndex = 41;
            this.lbl_verify_holi_startdate.Text = "起始日期";
            // 
            // lbl_verify_holi_endDate
            // 
            this.lbl_verify_holi_endDate.AutoSize = true;
            this.lbl_verify_holi_endDate.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_endDate.Location = new System.Drawing.Point(476, 364);
            this.lbl_verify_holi_endDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_endDate.Name = "lbl_verify_holi_endDate";
            this.lbl_verify_holi_endDate.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_endDate.TabIndex = 42;
            this.lbl_verify_holi_endDate.Text = "迄止日期";
            // 
            // lbl_verify_holi_offdayDays
            // 
            this.lbl_verify_holi_offdayDays.AutoSize = true;
            this.lbl_verify_holi_offdayDays.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_offdayDays.Location = new System.Drawing.Point(478, 417);
            this.lbl_verify_holi_offdayDays.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_verify_holi_offdayDays.Name = "lbl_verify_holi_offdayDays";
            this.lbl_verify_holi_offdayDays.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_offdayDays.TabIndex = 43;
            this.lbl_verify_holi_offdayDays.Text = "請假天數";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(619, 160);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 17);
            this.label12.TabIndex = 44;
            this.label12.Text = "Monica";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(619, 213);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 17);
            this.label13.TabIndex = 45;
            this.label13.Text = "Ted";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(619, 263);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(34, 17);
            this.label14.TabIndex = 46;
            this.label14.Text = "病假";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(619, 313);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 17);
            this.label15.TabIndex = 47;
            this.label15.Text = "2015/11/30";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(619, 364);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(82, 17);
            this.label16.TabIndex = 48;
            this.label16.Text = "2015/12/01";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(621, 417);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(16, 17);
            this.label17.TabIndex = 49;
            this.label17.Text = "2";
            // 
            // lbl_verify_holi_status
            // 
            this.lbl_verify_holi_status.AutoSize = true;
            this.lbl_verify_holi_status.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_verify_holi_status.Location = new System.Drawing.Point(477, 465);
            this.lbl_verify_holi_status.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbl_verify_holi_status.Name = "lbl_verify_holi_status";
            this.lbl_verify_holi_status.Size = new System.Drawing.Size(60, 17);
            this.lbl_verify_holi_status.TabIndex = 33;
            this.lbl_verify_holi_status.Text = "審核狀態";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(619, 465);
            this.label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 17);
            this.label18.TabIndex = 50;
            this.label18.Text = "尚未審核";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(622, 504);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(147, 156);
            this.textBox1.TabIndex = 51;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Firebrick;
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.ForeColor = System.Drawing.Color.Transparent;
            this.button2.Location = new System.Drawing.Point(660, 685);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 31);
            this.button2.TabIndex = 53;
            this.button2.Text = "退件";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.OliveDrab;
            this.button3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(479, 685);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 31);
            this.button3.TabIndex = 52;
            this.button3.Text = "通過";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // Frm_Verify_Holiday
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1089, 773);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbl_verify_holi_offdayDays);
            this.Controls.Add(this.lbl_verify_holi_endDate);
            this.Controls.Add(this.lbl_verify_holi_startdate);
            this.Controls.Add(this.lbl_verify_holi_offday_category);
            this.Controls.Add(this.lbl_verify_holi_jobchange);
            this.Controls.Add(this.lbl_verify_holi_name);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl_verify_holi_id_show);
            this.Controls.Add(this.lbl_verify_holi_id);
            this.Controls.Add(this.lbl_verify_holi_status);
            this.Controls.Add(this.lbl_verify_holi_rea);
            this.Controls.Add(this.lbl_verify_holi_empid);
            this.Controls.Add(this.btn_verify_cancel);
            this.Controls.Add(this.btn_verify_ok);
            this.Controls.Add(this.picbox_verify_holi);
            this.Controls.Add(this.btn_verify_holi_open);
            this.Controls.Add(this.lbl_verify_holi_proove);
            this.Controls.Add(this.dgv_verify_holi_list);
            this.Controls.Add(this.lbl_verify_holi_list);
            this.Controls.Add(this.lbl_verify_holi_title);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frm_Verify_Holiday";
            this.Text = "Frm_Verify_Holiday";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_verify_holi_list)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_verify_holi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_verify_holi_title;
        private System.Windows.Forms.Label lbl_verify_holi_list;
        private System.Windows.Forms.DataGridView dgv_verify_holi_list;
        private System.Windows.Forms.Label lbl_verify_holi_proove;
        private System.Windows.Forms.Button btn_verify_holi_open;
        private System.Windows.Forms.PictureBox picbox_verify_holi;
        private System.Windows.Forms.Button btn_verify_cancel;
        private System.Windows.Forms.Button btn_verify_ok;
        private System.Windows.Forms.Label lbl_verify_holi_rea;
        private System.Windows.Forms.Label lbl_verify_holi_empid;
        private System.Windows.Forms.Label lbl_verify_holi_id;
        private System.Windows.Forms.Label lbl_verify_holi_id_show;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_verify_holi_name;
        private System.Windows.Forms.Label lbl_verify_holi_jobchange;
        private System.Windows.Forms.Label lbl_verify_holi_offday_category;
        private System.Windows.Forms.Label lbl_verify_holi_startdate;
        private System.Windows.Forms.Label lbl_verify_holi_endDate;
        private System.Windows.Forms.Label lbl_verify_holi_offdayDays;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl_verify_holi_status;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}