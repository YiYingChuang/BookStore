﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore.請假系統_Ying
{
    public partial class FrmBigPicture : Form
    {
        public FrmBigPicture()
        {
            InitializeComponent();
        }
    }
}
