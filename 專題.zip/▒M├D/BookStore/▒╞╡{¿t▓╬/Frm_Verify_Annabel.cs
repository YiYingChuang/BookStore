﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form_Verify
{
    public partial class Frm_Verify_Annabel : Form
    {
        public Frm_Verify_Annabel()
        {
            InitializeComponent();
        }

        private void Frm_Verify_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void ibl_verify_applyreason_Click(object sender, EventArgs e)
        {

        }

        private void lbx_verify_location_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dom_verify_applyreason_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void lbl_verify_location_Click(object sender, EventArgs e)
        {

        }

        private void lbl_verify_applytime_Click(object sender, EventArgs e)
        {

        }
    }
}
