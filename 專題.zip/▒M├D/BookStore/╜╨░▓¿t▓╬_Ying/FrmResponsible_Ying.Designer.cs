﻿namespace BookStore.請假系統
{
    partial class FrmResponsible_Ying
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label absence_NoLabel;
            System.Windows.Forms.Label emp_NameLabel;
            System.Windows.Forms.Label statusLabel;
            System.Windows.Forms.Label label20;
            System.Windows.Forms.Label label24;
            System.Windows.Forms.Label label25;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmResponsible_Ying));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Browser = new System.Windows.Forms.Label();
            this.pictureBox_Browser = new System.Windows.Forms.PictureBox();
            this.Send = new System.Windows.Forms.Button();
            this.absence_Type1ComboBox = new System.Windows.Forms.ComboBox();
            this.btn_Browser = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_Alter = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.emp_NameTextBox = new System.Windows.Forms.TextBox();
            this.absence_TableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.absence_NoTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.certificate_DocPictureBox = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.absence_Type1ComboBox2 = new System.Windows.Forms.ComboBox();
            this.btn_Browser2 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.reasonTextBox = new System.Windows.Forms.TextBox();
            this.startDateTextBox = new System.Windows.Forms.TextBox();
            this.endDateTextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusLabel1 = new System.Windows.Forms.Label();
            this.pictureBox_CheckStatus = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_Reject = new System.Windows.Forms.Button();
            this.btn_Accept = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.absence_NoTextBox2 = new System.Windows.Forms.TextBox();
            this.emp_NameTextBox2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.absence_Type1ComboBox3 = new System.Windows.Forms.ComboBox();
            this.certificate_DocPictureBox2 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.reasonTextBox2 = new System.Windows.Forms.TextBox();
            this.startDateTextBox2 = new System.Windows.Forms.TextBox();
            this.endDateTextBox2 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.statusLabel2 = new System.Windows.Forms.Label();
            this.pictureBox_CheckStatus2 = new System.Windows.Forms.PictureBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            absence_NoLabel = new System.Windows.Forms.Label();
            emp_NameLabel = new System.Windows.Forms.Label();
            statusLabel = new System.Windows.Forms.Label();
            label20 = new System.Windows.Forms.Label();
            label24 = new System.Windows.Forms.Label();
            label25 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Browser)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.absence_TableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.certificate_DocPictureBox)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_CheckStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.certificate_DocPictureBox2)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_CheckStatus2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // absence_NoLabel
            // 
            absence_NoLabel.AutoSize = true;
            absence_NoLabel.Location = new System.Drawing.Point(44, 148);
            absence_NoLabel.Name = "absence_NoLabel";
            absence_NoLabel.Size = new System.Drawing.Size(72, 19);
            absence_NoLabel.TabIndex = 75;
            absence_NoLabel.Text = "請假單號:";
            // 
            // emp_NameLabel
            // 
            emp_NameLabel.AutoSize = true;
            emp_NameLabel.Location = new System.Drawing.Point(44, 95);
            emp_NameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            emp_NameLabel.Name = "emp_NameLabel";
            emp_NameLabel.Size = new System.Drawing.Size(72, 19);
            emp_NameLabel.TabIndex = 56;
            emp_NameLabel.Text = "員工姓名:";
            // 
            // statusLabel
            // 
            statusLabel.AutoSize = true;
            statusLabel.Location = new System.Drawing.Point(49, 90);
            statusLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new System.Drawing.Size(55, 19);
            statusLabel.TabIndex = 15;
            statusLabel.Text = "Status:";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new System.Drawing.Point(44, 148);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(72, 19);
            label20.TabIndex = 75;
            label20.Text = "請假單號:";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new System.Drawing.Point(44, 95);
            label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(72, 19);
            label24.TabIndex = 56;
            label24.Text = "員工姓名:";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new System.Drawing.Point(49, 90);
            label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(55, 19);
            label25.TabIndex = 15;
            label25.Text = "Status:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1056, 834);
            this.tabControl1.TabIndex = 21;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tabPage1.Size = new System.Drawing.Size(1048, 802);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "申請請假";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(27, 38);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(428, 42);
            this.label6.TabIndex = 20;
            this.label6.Text = "員工請假申請系統-申請請假\r\n";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dateTimePicker2);
            this.groupBox2.Controls.Add(this.dateTimePicker1);
            this.groupBox2.Controls.Add(this.panel1);
            this.groupBox2.Controls.Add(this.pictureBox_Browser);
            this.groupBox2.Controls.Add(this.Send);
            this.groupBox2.Controls.Add(this.absence_Type1ComboBox);
            this.groupBox2.Controls.Add(this.btn_Browser);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(9, 104);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox2.Size = new System.Drawing.Size(966, 689);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "請假表";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy年 MM月 dd日    tt hh時mm分";
            this.dateTimePicker2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(611, 115);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.ShowUpDown = true;
            this.dateTimePicker2.Size = new System.Drawing.Size(335, 27);
            this.dateTimePicker2.TabIndex = 21;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy年 MM月 dd日    tt hh時mm分";
            this.dateTimePicker1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(196, 115);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(335, 27);
            this.dateTimePicker1.TabIndex = 20;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.label_Browser);
            this.panel1.Location = new System.Drawing.Point(196, 428);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 86);
            this.panel1.TabIndex = 14;
            // 
            // label_Browser
            // 
            this.label_Browser.AutoSize = true;
            this.label_Browser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label_Browser.Location = new System.Drawing.Point(4, 27);
            this.label_Browser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Browser.Name = "label_Browser";
            this.label_Browser.Size = new System.Drawing.Size(77, 19);
            this.label_Browser.TabIndex = 10;
            this.label_Browser.Text = "                 ";
            this.label_Browser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox_Browser
            // 
            this.pictureBox_Browser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_Browser.Location = new System.Drawing.Point(196, 527);
            this.pictureBox_Browser.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.pictureBox_Browser.Name = "pictureBox_Browser";
            this.pictureBox_Browser.Size = new System.Drawing.Size(210, 139);
            this.pictureBox_Browser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Browser.TabIndex = 13;
            this.pictureBox_Browser.TabStop = false;
            // 
            // Send
            // 
            this.Send.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Send.Location = new System.Drawing.Point(780, 607);
            this.Send.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.Send.Name = "Send";
            this.Send.Size = new System.Drawing.Size(111, 57);
            this.Send.TabIndex = 19;
            this.Send.Text = "送出";
            this.Send.UseVisualStyleBackColor = true;
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // absence_Type1ComboBox
            // 
            this.absence_Type1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.absence_Type1ComboBox.FormattingEnabled = true;
            this.absence_Type1ComboBox.Location = new System.Drawing.Point(196, 42);
            this.absence_Type1ComboBox.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.absence_Type1ComboBox.Name = "absence_Type1ComboBox";
            this.absence_Type1ComboBox.Size = new System.Drawing.Size(202, 27);
            this.absence_Type1ComboBox.TabIndex = 12;
            this.absence_Type1ComboBox.SelectedIndexChanged += new System.EventHandler(this.absence_Type1ComboBox_SelectedIndexChanged);
            // 
            // btn_Browser
            // 
            this.btn_Browser.Location = new System.Drawing.Point(583, 446);
            this.btn_Browser.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_Browser.Name = "btn_Browser";
            this.btn_Browser.Size = new System.Drawing.Size(126, 47);
            this.btn_Browser.TabIndex = 11;
            this.btn_Browser.Text = "Browser...";
            this.btn_Browser.UseVisualStyleBackColor = true;
            this.btn_Browser.Click += new System.EventHandler(this.btn_Browser_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "請假類別:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(50, 115);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "請假起訖日:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 217);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "請假原因:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(196, 194);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(623, 194);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(50, 455);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "請假證明:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(560, 123);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "~";
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.btn_Alter);
            this.tabPage2.Controls.Add(this.btn_delete);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.tabPage2.Size = new System.Drawing.Size(1048, 802);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "查詢審核狀態";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btn_Alter
            // 
            this.btn_Alter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Alter.Location = new System.Drawing.Point(852, 697);
            this.btn_Alter.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_Alter.Name = "btn_Alter";
            this.btn_Alter.Size = new System.Drawing.Size(111, 57);
            this.btn_Alter.TabIndex = 76;
            this.btn_Alter.Text = "修改";
            this.btn_Alter.UseVisualStyleBackColor = true;
            this.btn_Alter.Click += new System.EventHandler(this.btn_Alter_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_delete.Location = new System.Drawing.Point(706, 697);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(111, 57);
            this.btn_delete.TabIndex = 75;
            this.btn_delete.Text = "刪除";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.emp_NameTextBox);
            this.groupBox3.Controls.Add(this.absence_NoTextBox);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.certificate_DocPictureBox);
            this.groupBox3.Controls.Add(this.panel2);
            this.groupBox3.Controls.Add(absence_NoLabel);
            this.groupBox3.Controls.Add(this.absence_Type1ComboBox2);
            this.groupBox3.Controls.Add(this.btn_Browser2);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.reasonTextBox);
            this.groupBox3.Controls.Add(this.startDateTextBox);
            this.groupBox3.Controls.Add(this.endDateTextBox);
            this.groupBox3.Controls.Add(emp_NameLabel);
            this.groupBox3.Location = new System.Drawing.Point(9, 104);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox3.Size = new System.Drawing.Size(485, 688);
            this.groupBox3.TabIndex = 74;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "假單明細:";
            // 
            // emp_NameTextBox
            // 
            this.emp_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.absence_TableBindingSource, "Emp_Information.Emp_Name", true));
            this.emp_NameTextBox.Location = new System.Drawing.Point(159, 92);
            this.emp_NameTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.emp_NameTextBox.Name = "emp_NameTextBox";
            this.emp_NameTextBox.ReadOnly = true;
            this.emp_NameTextBox.Size = new System.Drawing.Size(202, 27);
            this.emp_NameTextBox.TabIndex = 90;
            // 
            // absence_TableBindingSource
            // 
            this.absence_TableBindingSource.DataSource = typeof(BookStoreEntityModel.Absence_Table);
            // 
            // absence_NoTextBox
            // 
            this.absence_NoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.absence_TableBindingSource, "Absence_No", true));
            this.absence_NoTextBox.Location = new System.Drawing.Point(159, 145);
            this.absence_NoTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.absence_NoTextBox.Name = "absence_NoTextBox";
            this.absence_NoTextBox.ReadOnly = true;
            this.absence_NoTextBox.Size = new System.Drawing.Size(202, 27);
            this.absence_NoTextBox.TabIndex = 89;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(29, 254);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 19);
            this.label13.TabIndex = 86;
            this.label13.Text = "請假結束日:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(44, 42);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 19);
            this.label10.TabIndex = 83;
            this.label10.Text = "請假類別:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(29, 201);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 19);
            this.label11.TabIndex = 84;
            this.label11.Text = "請假起始日:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(44, 307);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 19);
            this.label12.TabIndex = 85;
            this.label12.Text = "請假原因:";
            // 
            // certificate_DocPictureBox
            // 
            this.certificate_DocPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.certificate_DocPictureBox.Location = new System.Drawing.Point(159, 534);
            this.certificate_DocPictureBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.certificate_DocPictureBox.Name = "certificate_DocPictureBox";
            this.certificate_DocPictureBox.Size = new System.Drawing.Size(210, 139);
            this.certificate_DocPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.certificate_DocPictureBox.TabIndex = 78;
            this.certificate_DocPictureBox.TabStop = false;
            this.certificate_DocPictureBox.Click += new System.EventHandler(this.certificate_DocPictureBox_Click);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(159, 451);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(115, 71);
            this.panel2.TabIndex = 82;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label7.Location = new System.Drawing.Point(4, 10);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 19);
            this.label7.TabIndex = 10;
            this.label7.Text = "                 ";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // absence_Type1ComboBox2
            // 
            this.absence_Type1ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.absence_Type1ComboBox2.ForeColor = System.Drawing.Color.Black;
            this.absence_Type1ComboBox2.FormattingEnabled = true;
            this.absence_Type1ComboBox2.Location = new System.Drawing.Point(159, 39);
            this.absence_Type1ComboBox2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.absence_Type1ComboBox2.Name = "absence_Type1ComboBox2";
            this.absence_Type1ComboBox2.Size = new System.Drawing.Size(202, 27);
            this.absence_Type1ComboBox2.TabIndex = 70;
            this.absence_Type1ComboBox2.SelectedIndexChanged += new System.EventHandler(this.absence_Type1ComboBox2_SelectedIndexChanged);
            // 
            // btn_Browser2
            // 
            this.btn_Browser2.Location = new System.Drawing.Point(285, 451);
            this.btn_Browser2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_Browser2.Name = "btn_Browser2";
            this.btn_Browser2.Size = new System.Drawing.Size(126, 47);
            this.btn_Browser2.TabIndex = 80;
            this.btn_Browser2.Text = "Browser...";
            this.btn_Browser2.UseVisualStyleBackColor = true;
            this.btn_Browser2.Click += new System.EventHandler(this.btn_Browser_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(46, 451);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 19);
            this.label9.TabIndex = 79;
            this.label9.Text = "請假證明:";
            // 
            // reasonTextBox
            // 
            this.reasonTextBox.Location = new System.Drawing.Point(159, 304);
            this.reasonTextBox.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.reasonTextBox.Multiline = true;
            this.reasonTextBox.Name = "reasonTextBox";
            this.reasonTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.reasonTextBox.Size = new System.Drawing.Size(252, 123);
            this.reasonTextBox.TabIndex = 34;
            // 
            // startDateTextBox
            // 
            this.startDateTextBox.Location = new System.Drawing.Point(159, 198);
            this.startDateTextBox.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.startDateTextBox.Name = "startDateTextBox";
            this.startDateTextBox.ReadOnly = true;
            this.startDateTextBox.Size = new System.Drawing.Size(252, 27);
            this.startDateTextBox.TabIndex = 72;
            // 
            // endDateTextBox
            // 
            this.endDateTextBox.Location = new System.Drawing.Point(159, 251);
            this.endDateTextBox.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.endDateTextBox.Name = "endDateTextBox";
            this.endDateTextBox.ReadOnly = true;
            this.endDateTextBox.Size = new System.Drawing.Size(252, 27);
            this.endDateTextBox.TabIndex = 71;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(27, 38);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(428, 42);
            this.label8.TabIndex = 21;
            this.label8.Text = "員工請假申請系統-審核狀態";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(statusLabel);
            this.groupBox1.Controls.Add(this.statusLabel1);
            this.groupBox1.Controls.Add(this.pictureBox_CheckStatus);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Location = new System.Drawing.Point(502, 104);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox1.Size = new System.Drawing.Size(515, 438);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "審核狀態";
            // 
            // statusLabel1
            // 
            this.statusLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.statusLabel1.Location = new System.Drawing.Point(116, 81);
            this.statusLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.statusLabel1.Name = "statusLabel1";
            this.statusLabel1.Size = new System.Drawing.Size(169, 47);
            this.statusLabel1.TabIndex = 16;
            this.statusLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox_CheckStatus
            // 
            this.pictureBox_CheckStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_CheckStatus.Location = new System.Drawing.Point(312, 42);
            this.pictureBox_CheckStatus.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.pictureBox_CheckStatus.Name = "pictureBox_CheckStatus";
            this.pictureBox_CheckStatus.Size = new System.Drawing.Size(136, 125);
            this.pictureBox_CheckStatus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_CheckStatus.TabIndex = 15;
            this.pictureBox_CheckStatus.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 190);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(496, 238);
            this.dataGridView1.TabIndex = 76;
            this.dataGridView1.CurrentCellChanged += new System.EventHandler(this.dataGridView1_CurrentCellChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.splitContainer1);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1048, 802);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "員工請假審核";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label14);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.Controls.Add(this.btn_Reject);
            this.splitContainer1.Panel2.Controls.Add(this.btn_Accept);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox4);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox5);
            this.splitContainer1.Size = new System.Drawing.Size(1048, 802);
            this.splitContainer1.SplitterDistance = 95;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(27, 38);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(428, 42);
            this.label14.TabIndex = 22;
            this.label14.Text = "員工請假申請系統-請假審核";
            // 
            // btn_Reject
            // 
            this.btn_Reject.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Reject.Location = new System.Drawing.Point(852, 597);
            this.btn_Reject.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_Reject.Name = "btn_Reject";
            this.btn_Reject.Size = new System.Drawing.Size(111, 57);
            this.btn_Reject.TabIndex = 78;
            this.btn_Reject.Text = "拒絕";
            this.btn_Reject.UseVisualStyleBackColor = true;
            this.btn_Reject.Click += new System.EventHandler(this.btn_Reject_Click);
            // 
            // btn_Accept
            // 
            this.btn_Accept.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Accept.Location = new System.Drawing.Point(706, 597);
            this.btn_Accept.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.btn_Accept.Name = "btn_Accept";
            this.btn_Accept.Size = new System.Drawing.Size(111, 57);
            this.btn_Accept.TabIndex = 77;
            this.btn_Accept.Text = "接受";
            this.btn_Accept.UseVisualStyleBackColor = true;
            this.btn_Accept.Click += new System.EventHandler(this.btn_Accept_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.absence_NoTextBox2);
            this.groupBox4.Controls.Add(this.emp_NameTextBox2);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.absence_Type1ComboBox3);
            this.groupBox4.Controls.Add(this.certificate_DocPictureBox2);
            this.groupBox4.Controls.Add(label20);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.reasonTextBox2);
            this.groupBox4.Controls.Add(this.startDateTextBox2);
            this.groupBox4.Controls.Add(this.endDateTextBox2);
            this.groupBox4.Controls.Add(label24);
            this.groupBox4.Location = new System.Drawing.Point(9, 4);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox4.Size = new System.Drawing.Size(485, 672);
            this.groupBox4.TabIndex = 76;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "假單明細:";
            // 
            // absence_NoTextBox2
            // 
            this.absence_NoTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.absence_TableBindingSource, "Absence_No", true));
            this.absence_NoTextBox2.Location = new System.Drawing.Point(159, 145);
            this.absence_NoTextBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.absence_NoTextBox2.Name = "absence_NoTextBox2";
            this.absence_NoTextBox2.ReadOnly = true;
            this.absence_NoTextBox2.Size = new System.Drawing.Size(202, 27);
            this.absence_NoTextBox2.TabIndex = 88;
            // 
            // emp_NameTextBox2
            // 
            this.emp_NameTextBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.absence_TableBindingSource, "Emp_Information.Emp_Name", true));
            this.emp_NameTextBox2.Location = new System.Drawing.Point(159, 92);
            this.emp_NameTextBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.emp_NameTextBox2.Name = "emp_NameTextBox2";
            this.emp_NameTextBox2.ReadOnly = true;
            this.emp_NameTextBox2.Size = new System.Drawing.Size(202, 27);
            this.emp_NameTextBox2.TabIndex = 87;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(29, 254);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 19);
            this.label15.TabIndex = 86;
            this.label15.Text = "請假結束日:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(44, 42);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 19);
            this.label16.TabIndex = 83;
            this.label16.Text = "請假類別:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(29, 201);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 19);
            this.label17.TabIndex = 84;
            this.label17.Text = "請假起始日:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(44, 307);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 19);
            this.label18.TabIndex = 85;
            this.label18.Text = "請假原因:";
            // 
            // absence_Type1ComboBox3
            // 
            this.absence_Type1ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.absence_Type1ComboBox3.ForeColor = System.Drawing.Color.Black;
            this.absence_Type1ComboBox3.FormattingEnabled = true;
            this.absence_Type1ComboBox3.Location = new System.Drawing.Point(159, 39);
            this.absence_Type1ComboBox3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.absence_Type1ComboBox3.Name = "absence_Type1ComboBox3";
            this.absence_Type1ComboBox3.Size = new System.Drawing.Size(202, 27);
            this.absence_Type1ComboBox3.TabIndex = 70;
            this.absence_Type1ComboBox3.SelectedIndexChanged += new System.EventHandler(this.absence_Type1ComboBox3_SelectedIndexChanged);
            // 
            // certificate_DocPictureBox2
            // 
            this.certificate_DocPictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.certificate_DocPictureBox2.Location = new System.Drawing.Point(159, 451);
            this.certificate_DocPictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.certificate_DocPictureBox2.Name = "certificate_DocPictureBox2";
            this.certificate_DocPictureBox2.Size = new System.Drawing.Size(210, 139);
            this.certificate_DocPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.certificate_DocPictureBox2.TabIndex = 78;
            this.certificate_DocPictureBox2.TabStop = false;
            this.certificate_DocPictureBox2.Click += new System.EventHandler(this.certificate_DocPictureBox_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(46, 451);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 19);
            this.label22.TabIndex = 79;
            this.label22.Text = "請假證明:";
            // 
            // reasonTextBox2
            // 
            this.reasonTextBox2.Location = new System.Drawing.Point(159, 304);
            this.reasonTextBox2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.reasonTextBox2.Multiline = true;
            this.reasonTextBox2.Name = "reasonTextBox2";
            this.reasonTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.reasonTextBox2.Size = new System.Drawing.Size(252, 123);
            this.reasonTextBox2.TabIndex = 34;
            // 
            // startDateTextBox2
            // 
            this.startDateTextBox2.Location = new System.Drawing.Point(159, 198);
            this.startDateTextBox2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.startDateTextBox2.Name = "startDateTextBox2";
            this.startDateTextBox2.ReadOnly = true;
            this.startDateTextBox2.Size = new System.Drawing.Size(252, 27);
            this.startDateTextBox2.TabIndex = 72;
            // 
            // endDateTextBox2
            // 
            this.endDateTextBox2.Location = new System.Drawing.Point(159, 251);
            this.endDateTextBox2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.endDateTextBox2.Name = "endDateTextBox2";
            this.endDateTextBox2.ReadOnly = true;
            this.endDateTextBox2.Size = new System.Drawing.Size(252, 27);
            this.endDateTextBox2.TabIndex = 71;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(label25);
            this.groupBox5.Controls.Add(this.statusLabel2);
            this.groupBox5.Controls.Add(this.pictureBox_CheckStatus2);
            this.groupBox5.Controls.Add(this.dataGridView2);
            this.groupBox5.Location = new System.Drawing.Point(502, 4);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.groupBox5.Size = new System.Drawing.Size(515, 438);
            this.groupBox5.TabIndex = 75;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "審核狀態";
            // 
            // statusLabel2
            // 
            this.statusLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.statusLabel2.Location = new System.Drawing.Point(116, 81);
            this.statusLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.statusLabel2.Name = "statusLabel2";
            this.statusLabel2.Size = new System.Drawing.Size(169, 47);
            this.statusLabel2.TabIndex = 16;
            this.statusLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox_CheckStatus2
            // 
            this.pictureBox_CheckStatus2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_CheckStatus2.Location = new System.Drawing.Point(312, 42);
            this.pictureBox_CheckStatus2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.pictureBox_CheckStatus2.Name = "pictureBox_CheckStatus2";
            this.pictureBox_CheckStatus2.Size = new System.Drawing.Size(136, 125);
            this.pictureBox_CheckStatus2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_CheckStatus2.TabIndex = 15;
            this.pictureBox_CheckStatus2.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(9, 190);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(496, 238);
            this.dataGridView2.TabIndex = 76;
            this.dataGridView2.CurrentCellChanged += new System.EventHandler(this.dataGridView2_CurrentCellChanged);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "審核通過");
            this.imageList1.Images.SetKeyName(1, "審核未通過");
            this.imageList1.Images.SetKeyName(2, "審核中");
            this.imageList1.Images.SetKeyName(3, "-");
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FrmResponsible_Ying
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 834);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmResponsible_Ying";
            this.Text = "FrmResponsible_Ying";
            this.Load += new System.EventHandler(this.FrmResponsible_Ying_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Browser)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.absence_TableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.certificate_DocPictureBox)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_CheckStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.certificate_DocPictureBox2)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_CheckStatus2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Browser;
        private System.Windows.Forms.PictureBox pictureBox_Browser;
        private System.Windows.Forms.Button Send;
        private System.Windows.Forms.ComboBox absence_Type1ComboBox;
        private System.Windows.Forms.Button btn_Browser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btn_Alter;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox certificate_DocPictureBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_Browser2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox reasonTextBox;
        private System.Windows.Forms.TextBox startDateTextBox;
        private System.Windows.Forms.TextBox endDateTextBox;
        private System.Windows.Forms.ComboBox absence_Type1ComboBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label statusLabel1;
        private System.Windows.Forms.PictureBox pictureBox_CheckStatus;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox emp_NameTextBox2;
        private System.Windows.Forms.BindingSource absence_TableBindingSource;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox certificate_DocPictureBox2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox reasonTextBox2;
        private System.Windows.Forms.TextBox startDateTextBox2;
        private System.Windows.Forms.TextBox endDateTextBox2;
        private System.Windows.Forms.ComboBox absence_Type1ComboBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label statusLabel2;
        private System.Windows.Forms.PictureBox pictureBox_CheckStatus2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox absence_NoTextBox2;
        private System.Windows.Forms.Button btn_Reject;
        private System.Windows.Forms.Button btn_Accept;
        private System.Windows.Forms.TextBox absence_NoTextBox;
        private System.Windows.Forms.TextBox emp_NameTextBox;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}